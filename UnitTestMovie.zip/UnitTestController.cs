﻿using Moq;
using MoviesRESTFull.Controllers;
using MoviesRESTFull.Models;
using MoviesRESTFull.Services;

namespace UnitTestMovie
{
    public class UnitTestController
    {
        private readonly Mock<IMovieService> movieService;
        public UnitTestController()
        {
            movieService = new Mock<IMovieService>();
        }

        [Fact]
        public void GetMovieList_MovieList()
        {
            //arrange
            var movieList = GetMoviesData();
            movieService.Setup(x => x.GetMovieList())
                .Returns(movieList);
            var movieController = new MovieController(movieService.Object);

            //act
            var movieResult = movieController.MovieList();

            //assert
            Assert.NotNull(movieResult);
            Assert.Equal(GetMoviesData().Count(), movieResult.Count());
            Assert.Equal(GetMoviesData().ToString(), movieResult.ToString());
            Assert.True(movieList.Equals(movieResult));
        }

        [Fact]
        public void GetMovieByID_Movie()
        {
            //arrange
            var movieList = GetMoviesData();
            movieService.Setup(x => x.GetMovieById(2))
                .Returns(movieList[1]);
            var movieController = new MovieController(movieService.Object);

            //act
            var movieResult = movieController.GetMovieById(2);

            //assert
            Assert.NotNull(movieResult);
            Assert.Equal(movieList[1].id, movieResult.id);
            Assert.True(movieList[1].id == movieResult.id);
        }

        [Theory]
        [InlineData("Pengabdi Setan 2 Comunion")]
        public void CheckMovieExistOrNotByMovieTitle_Movie(string title)
        {
            //arrange
            var movieList = GetMoviesData();
            movieService.Setup(x => x.GetMovieList())
                .Returns(movieList);
            var movieController = new MovieController(movieService.Object);

            //act
            var movieResult = movieController.MovieList();
            var expectedMovieTitle = movieResult.ToList()[0].title;

            //assert
            Assert.Equal(title, expectedMovieTitle);

        }


        [Fact]
        public void AddMovie_Movie()
        {
            //arrange
            var movieList = GetMoviesData();
            movieService.Setup(x => x.AddMovie(movieList[2]))
                .Returns(movieList[2]);
            var movieController = new MovieController(movieService.Object);

            //act
            var movieResult = movieController.AddMovie(movieList[2]);

            //assert
            Assert.NotNull(movieResult);
            Assert.Equal(movieList[2].id, movieResult.id);
            Assert.True(movieList[2].id == movieResult.id);
        }


        private List<Movie> GetMoviesData()
        {
            List<Movie> moviesData = new List<Movie>
        {
            new Movie
            {
                id = 1,
                title = "Pengabdi Setan 2 Comunion",
                description = "adalah sebuah film horor Indonesia tahun 2022 yang disutradarai dan",
                rating = 7,
                image = "",
                created_at = DateTime.Now,
                updated_at = DateTime.Now
            },
            new Movie
            {
                id = 2,
                title = "Pengabdi Setan",
                description = "Adalah sebuah film karya Mytan",
                rating = 7,
                image = "",
                created_at = DateTime.Now,
                updated_at = DateTime.Now
            },
            new Movie
            {
                id = 3,
                title = "Avenger age of ultron",
                description = "adalah sebuah film karya Marvel Studios",
                rating = 8,
                image = "",
                created_at = DateTime.Now,
                updated_at = DateTime.Now
            }
        };
            return moviesData;
        }
    }
}
